/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.infraestructura.Modelo;

/**
 *
 * @author hp
 */
public class PersonaModelos {
   public int IdPersona;
   public int IdCiudad;
   public String Nombre;
   public String Apellido;
   public String TipoDocumento;
   public String NroDocumento;
   public String Direccion;
   public String Celular;
   public String Email;
   public String Estado;
    
}
