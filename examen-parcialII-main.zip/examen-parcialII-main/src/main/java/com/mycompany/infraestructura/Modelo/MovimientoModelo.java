/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.infraestructura.Modelo;

import java.util.Date;

/**
 *
 * @author hp
 */
public class MovimientoModelo {
    public int IdMovimiento;
    public int IdCuenta;
    public String TipoMovimiento;
    public float SalarioAnterior;
    public float SaldoActual;
    public float MontoMovimiento;
    public float CuentaOrigen;
    public float CuentaDestino;
    public float Canal;
    public Date FechaMovimiento;
    
}
